
export PATH=/opt/PapilaOne/bin:${PATH}

